@extends('layout')

@section('titulo')
  <title>Actor</title>
@endsection
@section ('resultados')
      <ol>


            <h2>{{$nombre}}</h2>
        

      </ol>




@endsection
