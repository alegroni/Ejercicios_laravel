<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="/css/estilo.css">
    <title>Base de Datos</title>
  </head>
  <body>
    @yield('titulo')
    @yield('resultados')
    @yield('buscador')
  </body>
</html>
