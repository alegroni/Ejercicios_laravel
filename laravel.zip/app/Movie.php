<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Movie extends Model
{
    protected $fillable = ['title', 'awards', 'rating', 'release_date'];

public function genero(){
  return $this->belongsTo(Genre::class, 'genre_id');
  
}

}
